# Agara Celluler APK — Phase 3

Android Studio project for the new Agara Celluler app using the separate Supabase project/database.

## Included
- Supabase Auth login + profile role
- Premium blue dashboard
- Omset Toko / Profit / Cash Tersisa
- Transaction hub:
  - Pulsa / Paket / PLN / PPOB via `record_service_sale`
  - E-Wallet via `record_wallet_sale`
  - Tarik Tunai via `record_withdrawal`
  - Pengeluaran via `record_expense`
- Analytics:
  - Dashboard summary
  - `get_sales_chart`
  - `get_recent_transactions`
- Stock:
  - `get_low_stock`
  - Owner/Karyawan distinction
- Owner cash session:
  - `open_cash_session`
  - `close_cash_session`
- Logout via Supabase Auth

## Supabase configuration
Create `local.properties` in the project root:

```properties
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

Do not commit secrets. The publishable/anon key is intended for the client; database security must remain enforced by RLS and server-side functions.

## Important
This is source code, not a compiled APK. Open the project in Android Studio, let Gradle sync, then Build > Build APK(s).

The wallet and product screens intentionally consume the existing RPC/table outputs instead of assuming unverified extra columns. If the actual `wallets` display columns need friendly provider names, the next revision can add a verified wallet DTO after inspecting the table schema.
